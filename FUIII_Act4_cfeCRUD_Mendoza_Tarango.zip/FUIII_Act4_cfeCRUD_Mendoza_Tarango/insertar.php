<?php
include("conexion.php");
$con=conectar();

$codigo = $_POST['codigo'];
$nombre = $_POST['Nombre'];
$fecha = $_POST['Fecha'];
$rfc = $_POST['RFC'];
$razon = $_POST['Razon'];
$dce = $_POST['DCE'];

$sql = "INSERT INTO factura VALUES ('$codigo','$nombre','$fecha','$rfc','$razon','$dce')";
$query=mysqli_query($con,$sql);

if($query){
    Header("Location: alumno.php");
} else {

}
?>