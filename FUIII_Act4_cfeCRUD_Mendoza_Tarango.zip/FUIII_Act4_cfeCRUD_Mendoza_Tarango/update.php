<?php
include("conexion.php");
$con=conectar();

$codigo = $_POST['codigo'];
$nombre = $_POST['Nombre'];
$fecha = $_POST['Fecha'];
$rfc = $_POST['RFC'];
$razon = $_POST['Razon'];
$dce = $_POST['DCE'];

$sql = "UPDATE `factura` SET `Nombre`='$nombre',`Fecha`='$fecha',`RFC`='$rfc',`Razon`='$razon',`DCE`='$dce' WHERE codigo = '$codigo'";
$query=mysqli_query($con,$sql);

if($query){
    Header("Location: alumno.php");
} else {

}
?>